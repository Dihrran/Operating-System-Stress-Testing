#!/bin/bash

while true
do

echo "Select option: "
echo "1. Start Minikube "
echo "2. Apply prometheus-config (if theres any changes)"
echo "3. Forward prometheus service"
echo "4. Forward grafana service"
echo "5. view kubectl process"
echo "6. kill process"
echo "0. Exit"
read -p "Enter option: " choice

case $choice in
0)
echo "Exitting program-----"
exit 0
;;

1)
minikube start 
minikube update-context
kubectl cluster-info
;;

2)
kubectl apply -f prometheus-config.yaml
kubectl delete pod -l app=prometheus -n monitoring
;;

3)
nohup  kubectl port-forward svc/prometheus 9090:9090 -n monitoring & 
;;

4)
nohup  kubectl port-forward svc/grafana 3000:3000 -n monitoring & disown
;;

5)
ps aux | grep kubectl
;;

6)
read -p "Enter pid to kill: " pid
kill $pid
;;

*)
echo "Invalid menu option"
;;
esac

done

